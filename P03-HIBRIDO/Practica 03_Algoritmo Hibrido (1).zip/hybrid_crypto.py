import os
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding
from cryptography.hazmat.primitives import hashes, padding as sym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import serialization

AES_KEY_SIZE = 32
AES_IV_SIZE = 16
RSA_KEY_SIZE = 2048
RSA_PUBLIC_EXPONENT = 65537


def generar_par_llaves_rsa(tam_bits: int = RSA_KEY_SIZE):
    clave_privada = rsa.generate_private_key(
        public_exponent=RSA_PUBLIC_EXPONENT,
        key_size=tam_bits,
    )
    clave_publica = clave_privada.public_key()
    return clave_privada, clave_publica


def Cifrado_AES_enviar_mensaje(mensaje: str, iv: bytes, clave: bytes = None):
    if len(iv) != AES_IV_SIZE:
        raise ValueError(f"El IV debe medir {AES_IV_SIZE} bytes (tamaño de bloque AES).")

    if clave is None:
        clave = os.urandom(AES_KEY_SIZE)
    elif len(clave) not in (16, 24, 32):
        raise ValueError("La clave AES debe medir 16, 24 o 32 bytes.")

    padder = sym_padding.PKCS7(algorithms.AES.block_size).padder()
    datos_planos = padder.update(mensaje.encode("utf-8")) + padder.finalize()

    cifrador = Cipher(algorithms.AES(clave), modes.CBC(iv)).encryptor()
    mensaje_cifrado = cifrador.update(datos_planos) + cifrador.finalize()

    return mensaje_cifrado, clave


def _descifrar_aes(mensaje_cifrado: bytes, clave: bytes, iv: bytes) -> str:
    descifrador = Cipher(algorithms.AES(clave), modes.CBC(iv)).decryptor()
    datos_planos_rellenados = descifrador.update(mensaje_cifrado) + descifrador.finalize()

    unpadder = sym_padding.PKCS7(algorithms.AES.block_size).unpadder()
    datos_planos = unpadder.update(datos_planos_rellenados) + unpadder.finalize()

    return datos_planos.decode("utf-8")


@dataclass
class PaqueteCifrado:
    mensajeCifrado_AES: bytes
    iv_cifrado_RSA: bytes


def get_Msj_And_Key(mensaje: str, RSA_Publica):
    iv = os.urandom(AES_IV_SIZE)
    mensajeCifrado_AES, clave_aes = Cifrado_AES_enviar_mensaje(mensaje, iv)

    clave_mas_iv = clave_aes + iv

    iv_cifrado_RSA = RSA_Publica.encrypt(
        clave_mas_iv,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    return PaqueteCifrado(mensajeCifrado_AES, iv_cifrado_RSA)


def decifrar_mensaje(mensajeCifrado_AES: bytes, iv_cifrado_RSA: bytes, RSA_Privada) -> str:
    clave_mas_iv = RSA_Privada.decrypt(
        iv_cifrado_RSA,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    clave_aes = clave_mas_iv[:AES_KEY_SIZE]
    iv = clave_mas_iv[AES_KEY_SIZE:AES_KEY_SIZE + AES_IV_SIZE]

    return _descifrar_aes(mensajeCifrado_AES, clave_aes, iv)


def exportar_llave_publica_pem(clave_publica) -> bytes:
    return clave_publica.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def exportar_llave_privada_pem(clave_privada, password: bytes = None) -> bytes:
    algoritmo_cifrado = (
        serialization.BestAvailableEncryption(password)
        if password
        else serialization.NoEncryption()
    )
    return clave_privada.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=algoritmo_cifrado,
    )
