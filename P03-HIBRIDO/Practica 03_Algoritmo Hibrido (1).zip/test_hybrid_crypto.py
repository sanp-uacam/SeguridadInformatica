import os
import unittest

from hybrid_crypto import (
    generar_par_llaves_rsa,
    get_Msj_And_Key,
    decifrar_mensaje,
    Cifrado_AES_enviar_mensaje,
    AES_IV_SIZE,
)


class TestCifradoHibrido(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.clave_privada, cls.clave_publica = generar_par_llaves_rsa()

    def test_ciclo_completo_cifrado_descifrado(self):
        mensaje_original = "Hola, este es un mensaje secreto para el examen."

        paquete = get_Msj_And_Key(mensaje_original, self.clave_publica)
        mensaje_recuperado = decifrar_mensaje(
            paquete.mensajeCifrado_AES,
            paquete.iv_cifrado_RSA,
            self.clave_privada,
        )

        self.assertEqual(mensaje_original, mensaje_recuperado)

    def test_mensaje_cifrado_no_es_igual_al_original(self):
        mensaje_original = "Otro mensaje de prueba"
        paquete = get_Msj_And_Key(mensaje_original, self.clave_publica)

        self.assertNotEqual(
            paquete.mensajeCifrado_AES,
            mensaje_original.encode("utf-8"),
        )

    def test_dos_cifrados_del_mismo_mensaje_son_distintos(self):
        mensaje = "mensaje repetido"
        p1 = get_Msj_And_Key(mensaje, self.clave_publica)
        p2 = get_Msj_And_Key(mensaje, self.clave_publica)

        self.assertNotEqual(p1.mensajeCifrado_AES, p2.mensajeCifrado_AES)
        self.assertNotEqual(p1.iv_cifrado_RSA, p2.iv_cifrado_RSA)

    def test_no_se_puede_descifrar_con_llave_privada_incorrecta(self):
        _, otra_clave_publica = generar_par_llaves_rsa()
        otra_clave_privada, _ = generar_par_llaves_rsa()

        mensaje = "mensaje confidencial"
        paquete = get_Msj_And_Key(mensaje, otra_clave_publica)

        with self.assertRaises(Exception):
            decifrar_mensaje(
                paquete.mensajeCifrado_AES,
                paquete.iv_cifrado_RSA,
                otra_clave_privada,
            )

    def test_funcion_auxiliar_aes_directamente(self):
        iv = os.urandom(AES_IV_SIZE)
        mensaje = "prueba directa de AES"

        cifrado, clave = Cifrado_AES_enviar_mensaje(mensaje, iv)

        from hybrid_crypto import _descifrar_aes
        recuperado = _descifrar_aes(cifrado, clave, iv)
        self.assertEqual(mensaje, recuperado)

    def test_iv_de_tamano_incorrecto_lanza_error(self):
        iv_invalido = os.urandom(10)
        with self.assertRaises(ValueError):
            Cifrado_AES_enviar_mensaje("texto", iv_invalido)

    def test_mensaje_largo_y_con_caracteres_especiales(self):
        mensaje_original = (
            "Ñandú, café, año, 中文测试, emoji 🔒🔑, "
            + "texto largo " * 50
        )
        paquete = get_Msj_And_Key(mensaje_original, self.clave_publica)
        mensaje_recuperado = decifrar_mensaje(
            paquete.mensajeCifrado_AES, paquete.iv_cifrado_RSA, self.clave_privada
        )
        self.assertEqual(mensaje_original, mensaje_recuperado)

    def test_mensaje_vacio(self):
        mensaje_original = ""
        paquete = get_Msj_And_Key(mensaje_original, self.clave_publica)
        mensaje_recuperado = decifrar_mensaje(
            paquete.mensajeCifrado_AES, paquete.iv_cifrado_RSA, self.clave_privada
        )
        self.assertEqual(mensaje_original, mensaje_recuperado)


if __name__ == "__main__":
    unittest.main(verbosity=2)
