# Documentación — Sistema de Cifrado Híbrido RSA + AES

## 1. Explicación del funcionamiento del algoritmo híbrido

El **cifrado híbrido** combina las ventajas de dos familias de algoritmos:

- **AES (simétrico):** muy rápido y eficiente para cifrar grandes volúmenes
  de datos, pero requiere que emisor y receptor compartan la misma clave
  secreta de antemano (problema de distribución de claves).
- **RSA (asimétrico):** resuelve el problema de distribución de claves
  porque el receptor solo necesita publicar su clave pública, pero es
  lento y solo puede cifrar bloques de datos pequeños (limitados por el
  tamaño del módulo).

La solución híbrida usa **RSA únicamente para proteger una clave AES
efímera**, y **AES para cifrar el mensaje real**. Así se obtiene la
velocidad de AES y la facilidad de distribución de claves de RSA.

### Flujo general

1. El **emisor** genera una clave AES aleatoria (`clave_AES`) y un vector
   de inicialización (`IV`), únicos para este mensaje.
2. Cifra el **mensaje** con `AES-256-CBC` usando `clave_AES` e `IV`
   → `mensajeCifrado_AES`.
3. Empaqueta `clave_AES || IV` (48 bytes) y lo cifra con la **clave
   pública RSA** del receptor usando `RSA-OAEP` → `iv_cifrado_RSA`.
4. El emisor envía al receptor únicamente: `mensajeCifrado_AES` +
   `iv_cifrado_RSA`. La clave AES y el IV en claro **nunca viajan por la
   red**.
5. El **receptor** usa su **clave privada RSA** para descifrar
   `iv_cifrado_RSA` y recuperar `clave_AES` e `IV`.
6. Con `clave_AES` e `IV` descifra `mensajeCifrado_AES` con AES-CBC y
   obtiene el mensaje original.

### Correspondencia con las funciones pedidas

| Función | Rol |
|---|---|
| `Cifrado_AES_enviar_mensaje(mensaje, iv)` | Cifra un mensaje con AES-CBC dado un IV (genera la clave AES si no se provee). Es la pieza reutilizable de cifrado simétrico. |
| `get_Msj_And_Key(mensaje, RSA_Publica)` | Orquesta todo el cifrado: genera clave+IV, llama a `Cifrado_AES_enviar_mensaje`, y cifra `clave‖IV` con RSA-OAEP. |
| `decifrar_mensaje(mensajeCifrado_AES, iv_cifrado_RSA, RSA_Privada)` | Invierte el proceso: RSA-descifra `clave‖IV`, luego AES-descifra el mensaje. |

---

## 2. Justificación de las elecciones de diseño

### 2.1 AES-256 en modo CBC

- **Tamaño de clave (32 bytes / 256 bits):** AES-256 ofrece el margen de
  seguridad más alto de la familia AES frente a ataques futuros
  (incluyendo un margen de precaución ante avances en cómputo cuántico,
  que reducirían a la mitad la seguridad efectiva de una clave simétrica).
  El costo de rendimiento frente a AES-128 es mínimo, por lo que en un
  esquema híbrido (donde AES solo cifra el mensaje, no todo el tráfico)
  se prioriza la seguridad.
- **Modo CBC:** es el modo solicitado explícitamente en el enunciado.
  Requiere:
  - Un **IV impredecible y distinto en cada cifrado** (por eso se genera
    con `os.urandom`, un generador criptográficamente seguro).
  - **Relleno (padding)** porque el mensaje debe ser múltiplo del tamaño
    de bloque (16 bytes); se usa el estándar **PKCS7**.
  - *Nota:* en un sistema de producción actual se preferiría un modo
    autenticado como **AES-GCM** (protege confidencialidad **e**
    integridad/autenticidad a la vez). Se documenta esta recomendación
    aunque la implementación sigue CBC por ser el modo pedido en la
    especificación.

### 2.2 Tamaño del IV: 16 bytes (corrección respecto al enunciado)

El enunciado menciona un IV de **32 bytes**, pero el estándar AES
**exige que el IV mida exactamente el tamaño de un bloque de AES, que es
de 16 bytes (128 bits)**, sin importar si la clave es de 128, 192 o 256
bits. Un IV de 32 bytes simplemente **no es válido** para el modo CBC de
AES (la librería lo rechazaría). Por eso la implementación usa
`AES_IV_SIZE = 16` y lo documenta explícitamente en el código
(`hybrid_crypto.AES_IV_SIZE`). Esta es una corrección técnica necesaria,
no una desviación arbitraria del enunciado.

### 2.3 RSA de 2048 bits con OAEP

- **Tamaño de clave (2048 bits):** es el mínimo recomendado actualmente
  por NIST y organismos como la ENISA para uso hasta el mediano plazo;
  3072 o 4096 bits se recomiendan para protección a más largo plazo. Se
  deja como parámetro configurable (`RSA_KEY_SIZE`).
- **Padding OAEP (Optimal Asymmetric Encryption Padding) en vez de
  PKCS#1 v1.5:** OAEP es el esquema de relleno recomendado hoy para
  cifrado RSA porque PKCS#1 v1.5 es vulnerable a ataques de tipo
  *padding oracle* (p. ej. el ataque de Bleichenbacher). Se usa
  `MGF1` con `SHA-256` como función hash.

### 2.4 Empaquetar clave + IV en un solo cifrado RSA

El enunciado permite dos variantes: cifrar el IV con RSA por separado, o
**empaquetarlo junto con la clave cifrada**. Se eligió la segunda opción:

- RSA-2048 con OAEP-SHA256 puede cifrar como máximo
  `256 − 2·32 − 2 = 190` bytes en un solo bloque.
- `clave_AES (32 bytes) + IV (16 bytes) = 48 bytes`, muy por debajo del
  límite, por lo que **una sola operación RSA** es suficiente.
- Esto reduce a la mitad las operaciones RSA (más lentas que AES) sin
  perder seguridad, y simplifica el protocolo (un solo blob cifrado que
  viaja junto al mensaje).

### 2.5 Generación aleatoria

Tanto la clave AES como el IV se generan con `os.urandom()`, que en
Python usa la fuente de aleatoriedad segura del sistema operativo
(`/dev/urandom` en Linux/macOS, `CryptGenRandom`/`BCryptGenRandom` en
Windows). Esto es indispensable: una clave o IV predecibles anulan la
seguridad de todo el esquema.

---

## 3. Diagrama de flujo del proceso

```mermaid
flowchart TD
    subgraph Emisor["EMISOR — get_Msj_And_Key()"]
        A[Mensaje en texto plano] --> B[Generar clave AES aleatoria 32B]
        A --> C[Generar IV aleatorio 16B]
        B --> D["Cifrado_AES_enviar_mensaje(mensaje, iv)"]
        C --> D
        D --> E[mensajeCifrado_AES]
        B --> F[Empaquetar clave || IV = 48B]
        C --> F
        F --> G[Cifrar con RSA-OAEP + Llave Pública del receptor]
        G --> H[iv_cifrado_RSA]
    end

    E --> I(("Canal de transmisión\n(inseguro)"))
    H --> I

    subgraph Receptor["RECEPTOR — decifrar_mensaje()"]
        I --> J[Recibe mensajeCifrado_AES + iv_cifrado_RSA]
        J --> K[Descifrar iv_cifrado_RSA con RSA-OAEP + Llave Privada]
        K --> L[Recuperar clave_AES e IV]
        L --> M[Descifrar mensajeCifrado_AES con AES-CBC]
        M --> N[Mensaje original en texto plano]
    end
```

### Diagrama en texto (respaldo si no se puede renderizar Mermaid)

```
EMISOR                                              RECEPTOR
------                                              --------
mensaje
  |
  |--> genera clave_AES (32B) --\
  |--> genera IV (16B) ---------+--> AES-CBC-Encrypt(mensaje) --> mensajeCifrado_AES ---+
  |                              |                                                       |
  |                              +--> clave_AES || IV (48B)                              |
  |                                        |                                             |
  |                                        v                                             |
  |                          RSA-OAEP-Encrypt(clave||IV, PublicKey)                       |
  |                                        |                                             |
  |                                        v                                             |
  |                                 iv_cifrado_RSA ---------------------------------------+
  |                                                                                       |
  +---------------------------------------------------------------------------------------+
                                    (canal inseguro)
                                                                                           |
                                                                                           v
                                                                    RECEPTOR recibe ambos valores
                                                                                           |
                                                                    RSA-OAEP-Decrypt(iv_cifrado_RSA,
                                                                                       PrivateKey)
                                                                                           |
                                                                              clave_AES || IV (48B)
                                                                                           |
                                                                    AES-CBC-Decrypt(mensajeCifrado_AES,
                                                                                     clave_AES, IV)
                                                                                           |
                                                                                           v
                                                                              mensaje original
```

---

## 4. Pruebas realizadas

El archivo `test_hybrid_crypto.py` contiene 8 pruebas automatizadas
(`unittest`) que verifican:

1. **Ciclo completo:** cifrar y descifrar reproduce el mensaje original.
2. El texto cifrado nunca es igual al texto plano.
3. Dos cifrados del mismo mensaje producen salidas distintas (por la
   aleatoriedad de clave e IV) — propiedad de **seguridad semántica**.
4. Descifrar con una llave privada que no corresponde al par falla con
   una excepción, en lugar de devolver datos incorrectos silenciosamente.
5. La función auxiliar `Cifrado_AES_enviar_mensaje` funciona de forma
   aislada.
6. Un IV de tamaño incorrecto (≠16 bytes) es rechazado explícitamente.
7. Mensajes largos, con acentos, ideogramas y emoji (UTF-8) se cifran y
   descifran correctamente.
8. Caso borde: mensaje vacío.

Resultado de la ejecución:

```
Ran 8 tests in 0.147s
OK
```

## 5. Cómo ejecutar

```bash
pip install cryptography
python -m unittest test_hybrid_crypto.py -v
```

Ejemplo de uso directo:

```python
from hybrid_crypto import generar_par_llaves_rsa, get_Msj_And_Key, decifrar_mensaje

privada, publica = generar_par_llaves_rsa()

paquete = get_Msj_And_Key("Mensaje secreto", publica)
mensaje = decifrar_mensaje(paquete.mensajeCifrado_AES, paquete.iv_cifrado_RSA, privada)

print(mensaje)  # "Mensaje secreto"
```
