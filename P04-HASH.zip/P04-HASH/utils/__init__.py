"""Utilidades de la práctica."""
