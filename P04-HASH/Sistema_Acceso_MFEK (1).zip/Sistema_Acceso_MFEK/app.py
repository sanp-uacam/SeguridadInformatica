from core import interfaz_login


if __name__ == "__main__":
    interfaz_login.iniciar()
