from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import base64


def cifrar(llave, mensaje):
    motor = AES.new(llave, AES.MODE_CBC)
    datos_cifrados = motor.encrypt(pad(mensaje.encode(), AES.block_size))
    vector_inicial = base64.b64encode(motor.iv).decode("utf-8")
    mensaje_cifrado = base64.b64encode(datos_cifrados).decode("utf-8")
    return vector_inicial, mensaje_cifrado


def descifrar(llave, vector_inicial, mensaje_cifrado):
    vector_inicial = base64.b64decode(vector_inicial)
    mensaje_cifrado = base64.b64decode(mensaje_cifrado)
    motor = AES.new(llave, AES.MODE_CBC, vector_inicial)
    texto_plano = unpad(motor.decrypt(mensaje_cifrado), AES.block_size)
    return texto_plano.decode("utf-8")


def generar_llave(tamano):
    return get_random_bytes(tamano)
