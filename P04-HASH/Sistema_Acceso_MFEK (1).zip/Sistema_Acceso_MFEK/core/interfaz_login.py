import hashlib
import hmac
import os
import string
import tkinter as tk
from tkinter import messagebox

from core import gestor_archivos


DIRECTORIO_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARCHIVO_CREDENCIALES = os.path.join(DIRECTORIO_BASE, "credenciales.json")


def generar_hash(clave):
    """Genera el hash SHA-256 de una clave."""
    return hashlib.sha256(clave.encode("utf-8")).hexdigest()


def contiene_secuencia_basica(clave, largo_secuencia=3):
    """Detecta secuencias básicas como abc, cba, 123 o 321."""
    texto = clave.lower()
    conjuntos = (string.ascii_lowercase, string.digits)

    for conjunto in conjuntos:
        for version in (conjunto, conjunto[::-1]):
            for i in range(len(version) - largo_secuencia + 1):
                fragmento = version[i:i + largo_secuencia]
                if fragmento in texto:
                    return True
    return False


def validar_clave(usuario, clave):
    """Valida las reglas establecidas para la clave de acceso."""
    problemas = []

    if len(clave) < 8:
        problemas.append("Debe tener al menos 8 caracteres.")
    if not any(caracter.isupper() for caracter in clave):
        problemas.append("Debe incluir al menos una mayúscula.")
    if not any(caracter.islower() for caracter in clave):
        problemas.append("Debe incluir al menos una minúscula.")
    if not any(not caracter.isalnum() and not caracter.isspace() for caracter in clave):
        problemas.append("Debe incluir al menos un carácter especial.")
    if usuario and usuario.lower() in clave.lower():
        problemas.append("No debe incluir el nombre de usuario.")
    if contiene_secuencia_basica(clave):
        problemas.append("No debe contener secuencias básicas como abc, cba, 123 o 321.")

    return problemas


class AplicacionAcceso:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Sistema de Autenticación - María F. Ek Chan")
        self.ventana.configure(bg="#eef1f5")

        # Las credenciales se cargan desde JSON. La clave nunca se guarda en texto plano.
        self.usuarios = gestor_archivos.cargar_datos(ARCHIVO_CREDENCIALES)
        if not isinstance(self.usuarios, dict):
            self.usuarios = {}

        self.construir_widgets()

    def generar_hash(self, clave):
        """Se mantiene el método dentro de la clase para usarlo desde el acceso."""
        return generar_hash(clave)

    def construir_widgets(self):
        marco_principal = tk.Frame(self.ventana, bg="#eef1f5", padx=24, pady=24)
        marco_principal.pack(expand=True, fill="both")

        etiqueta_titulo = tk.Label(
            marco_principal,
            text="Acceso al Sistema",
            font=("Segoe UI", 19, "bold"),
            bg="#eef1f5",
            fg="#20293a",
        )
        etiqueta_titulo.pack(pady=(0, 6))

        tk.Label(
            marco_principal,
            text="Módulo de Autenticación  •  Autora: María F. Ek Chan",
            font=("Segoe UI", 10, "italic"),
            bg="#eef1f5",
            fg="#5b6472",
        ).pack(pady=(0, 20))

        marco_campos = tk.Frame(marco_principal, bg="#eef1f5")
        marco_campos.pack(pady=10)

        tk.Label(
            marco_campos,
            text="Correo/Usuario:",
            font=("Segoe UI", 12),
            bg="#eef1f5",
            anchor="w",
            width=16,
        ).grid(row=0, column=0, padx=6, pady=10, sticky="w")

        self.campo_usuario = tk.Entry(marco_campos, font=("Segoe UI", 12), width=20)
        self.campo_usuario.grid(row=0, column=1, padx=6, pady=10)
        self.campo_usuario.focus()

        tk.Label(
            marco_campos,
            text="Clave de acceso:",
            font=("Segoe UI", 12),
            bg="#eef1f5",
            anchor="w",
            width=16,
        ).grid(row=1, column=0, padx=6, pady=10, sticky="w")

        self.campo_clave = tk.Entry(marco_campos, font=("Segoe UI", 12), width=20, show="●")
        self.campo_clave.grid(row=1, column=1, padx=6, pady=10)
        self.campo_clave.bind("<Return>", lambda evento: self.iniciar_sesion())

        marco_botones = tk.Frame(marco_principal, bg="#eef1f5")
        marco_botones.pack(pady=16)

        tk.Button(
            marco_botones,
            text="Ingresar",
            font=("Segoe UI", 12, "bold"),
            bg="#2E8B57",
            fg="white",
            width=15,
            command=self.iniciar_sesion,
        ).pack(pady=5)

        tk.Button(
            marco_botones,
            text="Crear cuenta",
            font=("Segoe UI", 12, "bold"),
            bg="#3F51B5",
            fg="white",
            width=15,
            command=self.abrir_registro,
        ).pack(pady=5)

        tk.Button(
            marco_botones,
            text="Borrar campos",
            font=("Segoe UI", 10),
            bg="#C62828",
            fg="white",
            width=11,
            command=self.limpiar_campos,
        ).pack(pady=5)

    def abrir_registro(self):
        """Abre una ventana para dar de alta un nuevo usuario."""
        ventana_registro = tk.Toplevel(self.ventana)
        ventana_registro.title("Alta de Usuario - María F. Ek Chan")
        ventana_registro.geometry("480x440")
        ventana_registro.resizable(False, False)
        ventana_registro.configure(bg="#eef1f5")
        ventana_registro.transient(self.ventana)
        ventana_registro.grab_set()

        tk.Label(
            ventana_registro,
            text="Nuevo Registro",
            font=("Segoe UI", 19, "bold"),
            bg="#eef1f5",
        ).pack(pady=(22, 4))

        tk.Label(
            ventana_registro,
            text="Módulo de Autenticación  •  María F. Ek Chan",
            font=("Segoe UI", 9, "italic"),
            bg="#eef1f5",
            fg="#5b6472",
        ).pack(pady=(0, 12))

        formulario = tk.Frame(ventana_registro, bg="#eef1f5")
        formulario.pack()

        tk.Label(formulario, text="Usuario:", font=("Segoe UI", 11), bg="#eef1f5").grid(
            row=0, column=0, padx=10, pady=9, sticky="w"
        )
        campo_usuario_nuevo = tk.Entry(formulario, font=("Segoe UI", 11), width=25)
        campo_usuario_nuevo.grid(row=0, column=1, padx=10, pady=9)

        tk.Label(formulario, text="Clave:", font=("Segoe UI", 11), bg="#eef1f5").grid(
            row=1, column=0, padx=10, pady=9, sticky="w"
        )
        campo_clave_nueva = tk.Entry(formulario, font=("Segoe UI", 11), width=25, show="●")
        campo_clave_nueva.grid(row=1, column=1, padx=10, pady=9)

        tk.Label(formulario, text="Repetir clave:", font=("Segoe UI", 11), bg="#eef1f5").grid(
            row=2, column=0, padx=10, pady=9, sticky="w"
        )
        campo_clave_repetida = tk.Entry(formulario, font=("Segoe UI", 11), width=25, show="●")
        campo_clave_repetida.grid(row=2, column=1, padx=10, pady=9)

        texto_reglas = (
            "La clave de acceso debe cumplir con:\n"
            "• Mínimo 8 caracteres\n"
            "• Mayúsculas y minúsculas\n"
            "• Al menos un carácter especial\n"
            "• Sin secuencias básicas (abc, 123, etc.)\n"
            "• No incluir el nombre de usuario"
        )
        tk.Label(
            ventana_registro,
            text=texto_reglas,
            justify="left",
            font=("Segoe UI", 10),
            bg="#eef1f5",
            fg="#3a4250",
        ).pack(pady=14)

        def registrar_nuevo_usuario():
            usuario = campo_usuario_nuevo.get().strip()
            clave = campo_clave_nueva.get()
            repeticion = campo_clave_repetida.get()

            if not usuario or not clave or not repeticion:
                messagebox.showerror("Error", "Complete todos los campos.", parent=ventana_registro)
                return

            if usuario in self.usuarios:
                messagebox.showerror("Error", "Ese usuario ya se encuentra registrado.", parent=ventana_registro)
                return

            if clave != repeticion:
                messagebox.showerror("Error", "Las claves ingresadas no coinciden.", parent=ventana_registro)
                return

            problemas = validar_clave(usuario, clave)
            if problemas:
                messagebox.showerror(
                    "Clave no válida",
                    "Corrija lo siguiente:\n\n" + "\n".join(f"• {p}" for p in problemas),
                    parent=ventana_registro,
                )
                return

            # Se guarda únicamente el hash SHA-256, nunca la clave original.
            self.usuarios[usuario] = self.generar_hash(clave)

            if not gestor_archivos.guardar_datos(self.usuarios, ARCHIVO_CREDENCIALES):
                self.usuarios.pop(usuario, None)
                messagebox.showerror("Error", "No fue posible guardar el usuario.", parent=ventana_registro)
                return

            messagebox.showinfo(
                "Registro exitoso",
                "Usuario registrado correctamente.\nLa clave fue almacenada como hash SHA-256.",
                parent=ventana_registro,
            )
            self.campo_usuario.delete(0, tk.END)
            self.campo_usuario.insert(0, usuario)
            self.campo_clave.delete(0, tk.END)
            ventana_registro.destroy()
            self.campo_clave.focus()

        tk.Button(
            ventana_registro,
            text="Guardar cuenta",
            font=("Segoe UI", 11, "bold"),
            bg="#3F51B5",
            fg="white",
            width=17,
            command=registrar_nuevo_usuario,
        ).pack(pady=10)

        campo_usuario_nuevo.focus()

    def iniciar_sesion(self):
        """Hashea la clave ingresada y la compara con la almacenada."""
        usuario = self.campo_usuario.get().strip()
        clave = self.campo_clave.get()

        if not usuario or not clave:
            messagebox.showerror("Error", "Por favor, complete todos los campos")
            return

        hash_guardado = self.usuarios.get(usuario)
        if hash_guardado is None:
            messagebox.showerror("Error", "Usuario no encontrado")
            return

        hash_ingresado = self.generar_hash(clave)

        # El acceso solo es válido si ambos hashes coinciden.
        if hmac.compare_digest(hash_guardado, hash_ingresado):
            messagebox.showinfo("Acceso concedido", f"¡Bienvenida/o, {usuario}!")
            self.abrir_panel(usuario)
        else:
            messagebox.showerror("Error", "Clave incorrecta")

    def limpiar_campos(self):
        self.campo_usuario.delete(0, tk.END)
        self.campo_clave.delete(0, tk.END)
        self.campo_usuario.focus()

    def abrir_panel(self, usuario):
        self.ventana.withdraw()

        panel = tk.Toplevel(self.ventana)
        panel.title("Panel Principal - María F. Ek Chan")
        panel.geometry("620x420")
        panel.configure(bg="#ffffff")

        tk.Label(
            panel,
            text=f"Sesión iniciada, {usuario}!",
            font=("Segoe UI", 16, "bold"),
            bg="#ffffff",
            fg="#20293a",
        ).pack(pady=(50, 10))

        tk.Label(
            panel,
            text="Sistema de Autenticación\nAutora: María F. Ek Chan",
            font=("Segoe UI", 11),
            bg="#ffffff",
            fg="#5b6472",
            justify="center",
        ).pack(pady=10)

        def cerrar_sesion():
            panel.destroy()
            self.limpiar_campos()
            self.ventana.deiconify()

        tk.Button(
            panel,
            text="Cerrar sesión",
            font=("Segoe UI", 12),
            bg="#EF6C00",
            fg="white",
            command=cerrar_sesion,
        ).pack(pady=22)


def iniciar():
    raiz = tk.Tk()

    ancho_ventana = 420
    alto_ventana = 470
    ancho_pantalla = raiz.winfo_screenwidth()
    alto_pantalla = raiz.winfo_screenheight()
    x = (ancho_pantalla - ancho_ventana) // 2
    y = (alto_pantalla - alto_ventana) // 2
    raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{x}+{y}")
    raiz.resizable(False, False)

    AplicacionAcceso(raiz)
    raiz.mainloop()


if __name__ == "__main__":
    iniciar()
