import json
import os


def guardar_datos(informacion, ruta_archivo):
    try:
        with open(ruta_archivo, "w", encoding="utf-8") as f:
            json.dump(informacion, f, ensure_ascii=False, indent=4)
        print(f"Información almacenada correctamente en {ruta_archivo}")
        return True
    except Exception as error:
        print(f"No se pudo almacenar la información: {error}")
        return False


def cargar_datos(ruta_archivo):
    try:
        if not os.path.exists(ruta_archivo):
            print("El archivo indicado no existe todavía")
            return {}

        with open(ruta_archivo, "r", encoding="utf-8") as f:
            informacion = json.load(f)
        print(f"Información recuperada correctamente desde {ruta_archivo}")
        return informacion
    except Exception as error:
        print(f"No se pudo recuperar la información: {error}")
        return {}


# Ejemplo de uso:
# registro = {"llave": "dato", "cantidad": 7, "elementos": [4, 5, 6]}
# guardar_datos(registro, "credenciales.json")
# registro_cargado = cargar_datos("credenciales.json")
# print(registro_cargado)
